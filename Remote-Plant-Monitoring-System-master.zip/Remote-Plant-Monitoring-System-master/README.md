# Remote-plant-monitoring-system

The objective of the project is to manage the plant life using sensors and the framework used is django.
